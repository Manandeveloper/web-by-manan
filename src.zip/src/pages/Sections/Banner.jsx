import React from "react";
const Banner = () => {
    return(
        <div className="banner">
            <h1>FrontEnd Developer & Freelancer</h1>
            <div className="hero-white"></div>
        </div>
    );
}
export default Banner;